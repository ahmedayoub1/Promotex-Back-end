﻿namespace PromoTex.DTO.Category
{
    public class UpdateCategoryDTO
    {
        public string Name { get; set; }
    }
}
