﻿namespace PromoTex.DTO
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
