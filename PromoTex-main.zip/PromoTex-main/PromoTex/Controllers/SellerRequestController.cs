﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PromoTex.Models;
using PromoTex.Services;
using PromoTex.Utility;

namespace PromoTex.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SellerRequestController : ControllerBase
    {
      
    }
}
