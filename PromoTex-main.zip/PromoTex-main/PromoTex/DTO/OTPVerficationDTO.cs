﻿namespace PromoTex.DTO
{
    public class OTPVerficationDTO
    {
        public string OTP { get; set; }
    }
}
