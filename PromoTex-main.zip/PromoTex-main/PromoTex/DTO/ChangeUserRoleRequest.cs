﻿namespace PromoTex.DTO
{
    public class ChangeUserRoleRequest
    {
        public string UserId { get; set; }
        public string NewRole { get; set; }
    }
}
