﻿namespace PromoTex.DTO.Category
{
    public class CreateCategoryDTO
    {
        public string Name { get; set; }
    }
}
