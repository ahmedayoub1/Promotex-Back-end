﻿namespace PromoTex.DTO
{
    public class ResetPasswordDto
    {
      
        public string OTP { get; set; }
        public string NewPassword { get; set; }

    }
}
