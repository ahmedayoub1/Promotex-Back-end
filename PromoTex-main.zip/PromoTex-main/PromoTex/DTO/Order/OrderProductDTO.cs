﻿namespace PromoTex.DTO.Order
{
    public class OrderProductDTO
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
