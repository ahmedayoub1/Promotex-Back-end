﻿namespace PromoTex.DTO
{
    public class ResendEmailConfirmationDto
    {
        public string Email { get; set; }
    }

}
