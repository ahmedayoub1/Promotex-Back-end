﻿namespace PromoTex.Enums
{
    public enum RoleRequestStatus
    {
        Pending ,
        Approved,
        Rejected

    }
}
