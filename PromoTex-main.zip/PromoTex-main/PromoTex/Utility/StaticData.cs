﻿namespace PromoTex.Utility
{
    public static class StaticData
    {
        public const string AdminRole = "Admin";
        public const string CustomerRole = "User";
        public const string SellerRole = "Seller";
    }
}
